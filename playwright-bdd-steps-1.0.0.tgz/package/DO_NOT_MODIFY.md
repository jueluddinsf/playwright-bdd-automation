# ⛔ READ ONLY — DO NOT MODIFY

This package is maintained by the **QA Platform team**.

## You cannot commit changes from here

Files inside `node_modules/` are **not tracked by Git**.  
Any changes you make to these files will be **silently lost** the next time anyone runs:

```bash
npm install
```

## If you need a step changed or added

Raise a request with the **QA Platform team**. Do not attempt to patch files in `node_modules/`.

The team will release an updated version of the package, and you update by running `npm install`.
