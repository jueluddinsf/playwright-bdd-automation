const fs = require('fs');
const path = require('path');
const { When, Then } = require('@cucumber/cucumber');
const { expect } = require('@playwright/test');
const LocatorManager = require('../utils/LocatorManager');
const inputActions = require('../actions/InputActions');
const clickActions = require('../actions/ClickActions');

function resolveLocator(key) {
    return LocatorManager.getSelector(key);
}

function getMemoryValue(world, alias) {
    world.memory = world.memory || {};
    if (world.memory[alias] === undefined) {
        throw new Error(`No saved memory value found for alias "${alias}"`);
    }
    return String(world.memory[alias]);
}

function getNestedValue(source, dottedPath) {
    return dottedPath.split('.').reduce((current, part) => {
        if (current === undefined || current === null) return undefined;
        return current[part];
    }, source);
}

function getConfigValue(keyPath) {
    const configPath = path.join(process.cwd(), 'config', 'env.js');
    if (!fs.existsSync(configPath)) {
        throw new Error(`Config file not found at ${configPath}`);
    }

    delete require.cache[require.resolve(configPath)];
    const envConfig = require(configPath);
    const value = getNestedValue(envConfig, keyPath);
    if (value === undefined) {
        throw new Error(`Config value "${keyPath}" was not found in config/env.js`);
    }
    return String(value);
}

function getEnvValue(key) {
    const value = process.env[key];
    if (value === undefined) {
        throw new Error(`Environment variable "${key}" is not set`);
    }
    return String(value);
}

function resolveProjectPath(filePath) {
    return path.resolve(process.cwd(), filePath);
}

function dataTableRows(dataTable) {
    return dataTable.raw().filter((row) => row.some((cell) => String(cell).trim() !== ''));
}

When('I fill the following fields:', async function (dataTable) {
    for (const [key, value] of dataTableRows(dataTable)) {
        await inputActions.fill(this.page, resolveLocator(key), value);
    }
});

When('I type into the following fields:', async function (dataTable) {
    for (const [key, value] of dataTableRows(dataTable)) {
        await inputActions.type(this.page, resolveLocator(key), value);
    }
});

When('I click the following elements:', async function (dataTable) {
    for (const [key] of dataTableRows(dataTable)) {
        await clickActions.click(this.page, resolveLocator(key));
    }
});

When('I fill {string} with saved value {string}', async function (key, alias) {
    await inputActions.fill(this.page, resolveLocator(key), getMemoryValue(this, alias));
});

When('I fill {string} with config value {string}', async function (key, configKey) {
    await inputActions.fill(this.page, resolveLocator(key), getConfigValue(configKey));
});

When('I fill {string} with env value {string}', async function (key, envKey) {
    await inputActions.fill(this.page, resolveLocator(key), getEnvValue(envKey));
});

Then('the element {string} should contain saved value {string}', async function (key, alias) {
    await expect(this.page.locator(resolveLocator(key))).toContainText(getMemoryValue(this, alias));
});

Then('the element {string} should have saved value {string}', async function (key, alias) {
    await expect(this.page.locator(resolveLocator(key))).toHaveValue(getMemoryValue(this, alias));
});

Then('the element {string} should contain config value {string}', async function (key, configKey) {
    await expect(this.page.locator(resolveLocator(key))).toContainText(getConfigValue(configKey));
});

Then('the response path {string} should be {string}', async function (jsonPath, expectedValue) {
    const value = getNestedValue(this.responseBody, jsonPath);
    expect(value).not.toBeUndefined();
    expect(String(value)).toBe(expectedValue);
});

Then('the response path {string} should exist', async function (jsonPath) {
    expect(getNestedValue(this.responseBody, jsonPath)).not.toBeUndefined();
});

Then('the response array {string} should have {int} items', async function (jsonPath, expectedCount) {
    const value = getNestedValue(this.responseBody, jsonPath);
    expect(Array.isArray(value)).toBe(true);
    expect(value).toHaveLength(expectedCount);
});

When('I download file from {string} and save as {string}', async function (key, filePath) {
    const downloadPromise = this.page.waitForEvent('download');
    await clickActions.click(this.page, resolveLocator(key));
    const download = await downloadPromise;
    const targetPath = resolveProjectPath(filePath);
    await download.saveAs(targetPath);
    this.lastDownloadedFile = targetPath;
});

Then('file {string} should exist', function (filePath) {
    expect(fs.existsSync(resolveProjectPath(filePath))).toBe(true);
});

Then('file {string} should contain text {string}', function (filePath, expectedText) {
    const content = fs.readFileSync(resolveProjectPath(filePath), 'utf-8');
    expect(content).toContain(expectedText);
});

Then('the downloaded file should exist', function () {
    expect(this.lastDownloadedFile).toBeDefined();
    expect(fs.existsSync(this.lastDownloadedFile)).toBe(true);
});

Then('the downloaded file should contain text {string}', function (expectedText) {
    expect(this.lastDownloadedFile).toBeDefined();
    const content = fs.readFileSync(this.lastDownloadedFile, 'utf-8');
    expect(content).toContain(expectedText);
});

Then('the table {string} should contain row with text {string}', async function (key, expectedText) {
    const table = this.page.locator(resolveLocator(key));
    await expect(table.locator('tr').filter({ hasText: expectedText }).first()).toBeVisible();
});

Then('the list {string} should contain item {string}', async function (key, expectedText) {
    const list = this.page.locator(resolveLocator(key));
    await expect(list.locator('li').filter({ hasText: expectedText }).first()).toBeVisible();
});

Then('every element matching {string} should be visible', async function (key) {
    const elements = this.page.locator(resolveLocator(key));
    const count = await elements.count();
    expect(count).toBeGreaterThan(0);

    for (let index = 0; index < count; index++) {
        await expect(elements.nth(index)).toBeVisible();
    }
});

Then('every element matching {string} should contain text {string}', async function (key, expectedText) {
    const elements = this.page.locator(resolveLocator(key));
    const count = await elements.count();
    expect(count).toBeGreaterThan(0);

    for (let index = 0; index < count; index++) {
        await expect(elements.nth(index)).toContainText(expectedText);
    }
});
